x = input("welk getal wil je de tafel zien: ")
for i in range (1,11,1):
    print(int(x) * int(i))
    