for i in range (1,11,1):
    print(i * 100)