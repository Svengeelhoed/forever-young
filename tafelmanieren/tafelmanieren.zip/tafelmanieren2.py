for i in range(30,0,-1):
    print(i - 1)
    
print("oh shit de raket is gecrashed")