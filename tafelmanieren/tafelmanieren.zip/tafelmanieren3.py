for i in range(0,12):
    print(str(i * 1) + (" AM"))
for o in range(12,25):
    print(str(o * 1) + (" PM"))
